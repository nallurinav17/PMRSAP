#!/usr/bin/perl

use strict;
use Data::Dumper;

my ($CLLI, $counter_name, $counter_id);

my $start = $ARGV[0];
my $end   = $ARGV[1];

die "Start and End time needs to be part of argument\n" unless($start || $end);

my $schemadatapath = $ENV{SCHEMADATAPATH};
my @CLLIs = split(/ /, $ENV{midmDC});

my $clliMap = $ENV{CLLInameMap};

my %CLLImap;
map {
  my @a = split(/\:/, $_);
  $CLLImap{$a[0]} = $a[1];
} split(/ /, $clliMap);

my @counters = qw(MIDM_aggregated_data_DC_volume MIDM_data_processing_DC_duration MIDM_data_transfer_DC_duration MIDM_enriched_data_DC_volume SAP_IPFIX_DC_volume SAP_PilotPacket_DC_volume SAP_SubscriberIB_DC_volume);

my @total_counters = qw(MIDM_aggregated_data_total_volume MIDM_enriched_data_total_volume MIDM_data_transfer_total_duration MIDM_total_duration MIDM_data_processing_total_duration );

my %counters;

map {
  my $_val;
  foreach my $_a (split(/\_/, $_)) {
    unless($_val) {
      $_val = $_a .'_';
    }
    else {
      $_val .= uc(substr($_a, 0, 1));
    }
  }

 $counters{$_} = $_val;

} @counters;


my %total_counters;

map {
  my $_val;
  foreach my $_a (split(/\_/, $_)) {
    unless($_val) {
      $_val = $_a .'_';
    }
    else {
      $_val .= uc(substr($_a, 0, 1));
    }
  }

 $total_counters{$_} = $_val;

} @total_counters;

print table_header();

my %rrdValues;
foreach my $CLLI ( @CLLIs ) {
  $CLLI = $CLLImap{$CLLI} if(defined $CLLImap{$CLLI});

  foreach my $counter(keys %counters) {
    $counter_name = $counter;

    my $cmd = "rrdtool fetch schema/$CLLI-$counter_name.rrd AVERAGE --start $start --end $end | grep ^1";

    my @cmd_out = `$cmd`;
    if($counter_name =~ /duration/) {
      map {
        chomp($cmd_out[$_]);
        $cmd_out[$_] = [split(/: /, $cmd_out[$_])]->[-1];
        #$cmd_out[$_] = sprintf("%d", $cmd_out[$_]);
        #$cmd_out[$_] =~ s/(\d)(?=(\d{3})+(\D|$))/$1\,/g;
      } (0..$#cmd_out);
    }
    else {
      map {
        chomp($cmd_out[$_]);
        $cmd_out[$_] = [split(/: /, $cmd_out[$_])]->[-1];
        $cmd_out[$_] = sprintf("%d", $cmd_out[$_]);
        $cmd_out[$_] =~ s/(\d)(?=(\d{3})+(\D|$))/$1\,/g;
      } (0..$#cmd_out);
    }

    push @{$rrdValues{$CLLI}->{$counter_name}}, @cmd_out;
  }
}
    #print Dumper(\%rrdValues);

foreach my $CLLI (sort keys %rrdValues) {
  print "<tr>";

  print "<td>".$CLLI."</td>\n";

  print "<td>".$rrdValues{$CLLI}->{SAP_IPFIX_DC_volume}->[0]."</td>\n";
  print "<td></td>\n";

  print "<td>".$rrdValues{$CLLI}->{SAP_PilotPacket_DC_volume}->[0]."</td>\n";
  print "<td></td>\n";

  print "<td>".$rrdValues{$CLLI}->{SAP_SubscriberIB_DC_volume}->[0]."</td>\n";

  print "<td>".$rrdValues{$CLLI}->{MIDM_aggregated_data_DC_volume}->[0]."</td>\n";
  print "<td>".$rrdValues{$CLLI}->{MIDM_enriched_data_DC_volume}->[0]."</td>\n";
  print "<td>".$rrdValues{$CLLI}->{MIDM_data_processing_DC_duration}->[0]."</td>\n";
  print "<td>".$rrdValues{$CLLI}->{MIDM_data_transfer_DC_duration}->[0]."</td>\n";


  ##
  print "<td>".$rrdValues{$CLLI}->{SAP_IPFIX_DC_volume}->[1]."</td>\n";
  print "<td></td>\n";

  print "<td>".$rrdValues{$CLLI}->{SAP_PilotPacket_DC_volume}->[1]."</td>\n";
  print "<td></td>\n";

  print "<td>".$rrdValues{$CLLI}->{SAP_SubscriberIB_DC_volume}->[1]."</td>\n";
  
  print "<td>3.0.6rc6</td>\n";

  print "</tr>";
}

print "</table>
</body>

</html>";



sub table_header() {
  my $date = `date +%m/%d/%Y`;chomp($date);
  my $header = <<DATA;
<!DOCTYPE html>
<html>

<head>
<style>
table,th,td
{
border:1px solid black;
border-collapse:collapse;
}
th,td
{
padding:5px;
}
</style>
</head>

<body>
<h3>CMDS & PNSA - MIDM Processing Report Day $date</h3>
<table style="width:300px">
<tr>
  <th>Subscriber Activity 2 days ago</th>
  <th>http (ipfix) (compressed bytes)
transaction files
2 days ago
</th>		
  <th>http (ipfix) 
records/sec
2 days ago
</th>		
  <th>pilotPacket (CDR)
(compressed bytes)
 2 days ago
</th>		
  <th>pilotPacket
records/sec
 2 days ago
</th>		
  <th>SubscriberIB
(bytes)
2 days ago
</th>		
  <th>MidmAgg
(compressed bytes)
</th>		
  <th>MidmEnr
(compressed bytes)
</th>		
  <th>Agg & Enr Processing
Duration
(hr:mn)
</th>		
  <th>Data Transfer
Duration
(hr:mn)
</th>		
  <th>http (ipfix) (compressed bytes)
transaction files
yesterday
</th>		
  <th>http (ipfix)
rec/sec
yesterday
</th>		
  <th>pilotPacket (CDR) (compressed bytes)
yesterday
</th>		
  <th>pilotPacket
rec/sec
 yesterday
</th>		
  <th>SubscriberIB
yesterday
</th>
  <th>Patches DC</th>
  </tr>

DATA

  return $header;
}


