#!/usr/bin/perl

use strict;
use Data::Dumper;

my ($CLLI, $counter_name, $counter_id);

print "Do you really want to create RRD schema (Y/N)? This will overwrite previous RRD files.\n";
exit(0) unless(<> =~ /y/i);

my $schemadatapath = $ENV{SCHEMADATAPATH};
my @CLLIs = split(/ /, $ENV{midmDC});

my $clliMap = $ENV{CLLInameMap};

my %CLLImap;
map {
  my @a = split(/\:/, $_);
  $CLLImap{$a[0]} = $a[1];
} split(/ /, $clliMap);

my $rrd_script = <<DATA;

rrdtool create $schemadatapath/CLLI-counter_name.rrd --start 1388578100 --step 86400  \\
        DS:counter_id:GAUGE:172800:0:U \\
        RRA:AVERAGE:0.5:1:777 \\
        RRA:AVERAGE:0.5:7:111 \\
        RRA:AVERAGE:0.5:30:25 \\
        RRA:MAX:0.5:7:111 \\
        RRA:MAX:0.5:30:25

DATA

#my @counters = qw(SAP_IPFIX_DC_volume SAP_PilotPacket_DC_volume SAP_SubscriberIB_DC_volume MIDM_aggregated_data_total_volume MIDM_enriched_data_total_volume MIDM_data_processing_DC_duration MIDM_data_transfer_DC_duration SAP_IPFIX_DC_volume SAP_PilotPacket_DC_volume SAP_SubscriberIB_DC_volume);

my @counters = qw(MIDM_aggregated_data_DC_volume MIDM_data_processing_DC_duration MIDM_data_transfer_DC_duration MIDM_enriched_data_DC_volume SAP_IPFIX_DC_volume SAP_PilotPacket_DC_volume SAP_SubscriberIB_DC_volume);

my @total_counters = qw(MIDM_aggregated_data_total_volume MIDM_enriched_data_total_volume MIDM_data_transfer_total_duration MIDM_total_duration MIDM_data_processing_total_duration );

my %counters;

map {
  my $_val;
  foreach my $_a (split(/\_/, $_)) {
    unless($_val) {
      $_val = $_a .'_';
    }
    else {
      $_val .= uc(substr($_a, 0, 1));
    }
  }

 $counters{$_} = $_val;

} @counters;


my %total_counters;

map {
  my $_val;
  foreach my $_a (split(/\_/, $_)) {
    unless($_val) {
      $_val = $_a .'_';
    }
    else {
      $_val .= uc(substr($_a, 0, 1));
    }
  }

 $total_counters{$_} = $_val;

} @total_counters;


foreach my $CLLI ( @CLLIs ) {
  $CLLI = $CLLImap{$CLLI} if(defined $CLLImap{$CLLI});

  foreach my $counter(keys %counters) {
    $counter_name = $counter;
    $counter_id = $counters{$counter_name};

    my $_rrd_script = $rrd_script;

    $_rrd_script =~ s/CLLI/$CLLI/g;
    $_rrd_script =~ s/counter_name.rrd/$counter_name.rrd/g;
    $_rrd_script =~ s/counter_id/$counter_id/g;

    print $_rrd_script;
    `$_rrd_script`;
  }
}

foreach my $counter(keys %total_counters) {
    $counter_name = $counter;
    $counter_id = $total_counters{$counter_name};

    my $_rrd_script = $rrd_script;

    $_rrd_script =~ s/CLLI-//g;
    $_rrd_script =~ s/counter_name.rrd/$counter_name.rrd/g;
    $_rrd_script =~ s/counter_id/$counter_id/g;

    print $_rrd_script;
    `$_rrd_script`;
}




