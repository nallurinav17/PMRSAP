use strict;

foreach my $date(1..30) {

  $date = "0$date" if(length($date) == 1);

  my $day = '201401'.$date;


  print "perl /var/home/monitor/GVS/rrdUpdater/rrdUpdater.pl $day\n";
  `perl /var/home/monitor/GVS/rrdUpdater/rrdUpdater.pl $day`;
}

