#!/usr/bin/perl

use strict;
use Time::Local;

use Data::Dumper;

my $RRD = $ENV{RRDTOOL};

my @counters = qw(MIDM_aggregated_data_DC_volume MIDM_aggregated_data_total_volume MIDM_data_processing_DC_duration MIDM_data_processing_total_duration MIDM_data_transfer_DC_duration MIDM_data_transfer_total_duration MIDM_enriched_data_DC_volume MIDM_enriched_data_total_volume MIDM_total_duration SAP_IPFIX_DC_volume SAP_PilotPacket_DC_volume SAP_SubscriberIB_DC_volume);
my %counters = map {$_ => 1} @counters;

my $date = $ARGV[0] || die "Date to be passed as parameter\n";

my $datapath = $ENV{SANDATA};
#$datapath = '/var/home/monitor/GVS/data';

my $rrdpath = $ENV{SCHEMADATAPATH};
#$rrdpath = '/var/home/monitor/GVS/schema';

my $clliMap = $ENV{CLLInameMap};

my %CLLImap;
map {
  my @a = split(/\:/, $_);
  $CLLImap{$a[0]} = $a[1];
} split(/ /, $clliMap);

my ($yy, $mm, $dd);
($yy, $mm, $dd) = ($1, $2, $3) if($date =~ /(\d{4})(\d{2})(\d{2})/);

die "Date to be passed as YYYYMMDD format" unless($yy ||  $mm || $dd);

# Get epoc for the date of file
# Since the data collected by SAP/getEnrDuration.sh is 1 day old, we will
# keep the chart in sync with the same reference of time. So, 1 day will be 
# removed from the epoc time.
my $time = timelocal(0,25,7,$dd,$mm-1,$yy-1900) - 1*60*60*24; 

my @files = `ls $datapath/$yy/$mm/$dd | grep '01d'`;

die "No files to process\n" unless(@files);

my %values;
foreach my $file(@files) {
  chomp($file);

  open(FL, "<$datapath/$yy/$mm/$dd/$file") or die "Unable to open file $datapath/$yy/$mm/$dd/$file for reading";

  while(my $row = <FL>) {
    chomp($row);
    $row =~ s/ //g;
    my @row = split(/,\s*/, $row);

    if (defined $counters{$row[3]}) {
      my $_clli = $row[2];
      $_clli = $CLLImap{$row[2]} if(defined $CLLImap{$row[2]});
      $values{$_clli}->{$row[3]} = $row[4];
    }
  }
}

#print Dumper(\%values);exit;
## Update RRD
foreach my $site (keys %values) {

  foreach my $counter(keys %{$values{$site}}) {
    my $cntr_val = $values{$site}->{$counter};
    my $rrd_file;

    if($site =~ /^MIDM$|^ALL_DC$/) {
      $rrd_file = "$rrdpath/$counter.rrd";    
    }
    else {
      $rrd_file = "$rrdpath/$site-$counter.rrd";
    }

    eval {
      print "$RRD update $rrd_file $time:$cntr_val\n";
      system("$RRD update $rrd_file $time:$cntr_val");
    };
    if($@) { 
      print "Error updating RRD $rrd_file, $!\n";
    }
  }
}

