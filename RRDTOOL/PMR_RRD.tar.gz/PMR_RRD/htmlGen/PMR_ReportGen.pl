#!/usr/bin/perl

use strict;
use Data::Dumper;

my $dcPNSA = $ENV{dcPNSA};
#my $dcPNSA="Westborough Windsor Rochester Syracuse Branchburg Wall HickoryHills NewBerlin Lodge Westland Columbus Duff Euless Schertz Memphis Tulsa Charlotte Nashville PembrokePines Orlando Sunnyvale Rocklin Marina Azusa Ontario Vista";

my $image_path = $ENV{BASEPATH} ."/htmlGen/images";

my $pnsaVersion = 'PNSA 2.0/2.2.rc5';
my $cmdsVersion = 'CMDS 1.6/3.0.6rc6';

my $from_date = `date +'%B %d, %Y' --date="30 days ago"`;chomp($from_date);
my $to_date   = `date +'%B %d, %Y'`;chomp($to_date);

my $data_from_date = `date +'%B %d, %Y' --date="31 days ago"`;chomp($data_from_date);
my $data_to_date   = `date +'%B %d, %Y' --date="1 days ago"`;chomp($data_to_date);

# HTML Start
print html_head();

print  html_summary($from_date, $to_date, $data_from_date, $data_to_date);

# HTML Executive Reporting
print html_execReporting();

# HTML Performance Management Summary
print html_perfSummary($data_from_date, $data_to_date);

# Sister Site specific charts
my $site_pairs = eval {do "$ENV{BASEPATH}/etc/SitePair.cfg"};

my %sitesArea;
foreach my $pairs (@$site_pairs) {
  my ($sites)     = keys %$pairs;
  my ($sitesValues) = values %$pairs;

  my ($sitesName) = keys %$sitesValues;
  my ($sitesArea) = values %$sitesValues;

  push @{$sitesArea{$sitesArea}}, {clliName => $sites, siteName => $sitesName};
}

my $Acount = 1;
foreach my $Area (sort keys %sitesArea) {

  print "<h2>2.$Acount $Area</h2>\n";
  my $cnt = 1;
  foreach my $pairs (@{$sitesArea{$Area}}) {
    my $sites     = $pairs->{'clliName'};
    my $sitesName = $pairs->{'siteName'};

    my $version;
    my $_siteName = [split(/\&/, $sitesName)]->[0];
    if($dcPNSA =~ /$_siteName/) {
      $version = $pnsaVersion;
    }
    else {
      $version = $cmdsVersion;
    }

    my ($site1, $site2) = split(/\:/, $sites);
    print html_siteMetrics($sitesName, $site1, $site2, "2.$Acount.$cnt", $version);
  
    $cnt++;
   } 

  $Acount++;
}

# HTML End
print htmlEnd();


#############################
# HTML Template Functions
# ###########################

sub html_head {
  my $html_head = <<HEAD;
<!DOCTYPE html>
<html>

<head>
<style>
table, th, td
{
border-collapse:collapse;
border:2px solid black;
}
th, td
{
padding:5px;
}

</style>
</head>
<body>
HEAD

  return $html_head;
}

sub html_summary {
  my ($from_date, $to_date, $data_from_date, $data_to_date) = @_;

  my $html_summary = <<DATA;

<h1 align=\"center\">Performance Management Executive Report Summary</h1>

<br><br>
<h2 align=\"center\">CMDS, PNSA MIDM Daily Traffic Report</h2>
<br>

<h3 align=\"center\">Reporting Date Range: $from_date to $to_date</h3>
<br>

<h4 align=\"center\">Draft Version</h4>
<br>

<!-- PAGE BREAK -->

DATA

  return $html_summary;
}


sub html_execReporting {

  my $html_execReporting = <<DATA;
<h2><a id="execSummary">1. Executive Summary</h2>
<p>The executive reporting shows the daily trends of various metrics related to MIDM processing. The visualization will help to identify any unexpected behavior in terms of both traffic and duration.</p>
  <h3>1.1 Executive Report</h3>
<ol type="a">
  <li><h4>Software Versions</li></h4>
<p>SAP 1.2 / Guavus 2.2.rc5 p3</p>
  <li><h4>System Events</li></h4>
  <li><h4>MIDM data processing, MIDM Transfer duration for all DCs</li></h4>
  <p>This chart shows the MIDM data processing and MIDM data transfer (to VZW IT) durations, as well as associated upper thresholds (dotted lines). An alarm is generated if a value goes over the threshold.</p>
  <img border="0" src="$image_path/processed_transfer_total_duration.png" alt="Pulpit rock" width="925" height="350">
  <br><br>

  <li><h4>Enriched MIDM Data, Aggregated MIDM Data for all DCs</li></h4>
  <p>This chart shows (Stacked area Charts) daily volume of MIDM Enriched and Aggregated Data records generated for all DCs.</p>
  <img border="0" src="$image_path/enriched_aggregeted_total_volume.png" alt="Pulpit rock" width="925" height="350">

  <br><br>
  <li><h4>MIDM data processing, MIDM Transfer duration, Enriched MIDM Data, Aggregated MIDM Data for all DCs</li></h4>

  <li><h4>Individual DC Events:</li></h4>

</ol>
<!-- PAGE BREAK -->
  <h3>1.2 Metrics Definition and Process Flow</h3>
  <p>Distribution Centers (DC)  collect mobile HTTP and Pilot Packet (AAA) subscriber traffic data in the Verizon Wireless, extract metadata,  format, enrich  and feed the data to the Subscriber Analytics platform at the NSS NEC in Colorado Springs.</p>
 <p>
DCs generate 3 types of data, HTTP records, Pilot Packets records and SubscriberIBs. HTTP and Pilot Packet records are generated every 5 minutes. SubscriberIB data is generated every hour.</p>
<p>
This data is sent continuously from the DCs to SAP over the EDN network. </p>
<p>
DCs are either CMDS DCs or PNSA DCs (depending on their implementation).</p>

<p>
The Subscriber Analytics Platforms (SAP) collects above data from all DCs and store it on its Hadoop cluster. 
SAP uses the data to support two applications:</p>
<p>
  - Mobile Internet Data Management (MIDM) application</p>
<p>
  - Network Security application
</p>
<p>
MIDM processes mobile subscriber data to feed VZW IT for the VZW Precision Market Insights solution .</p>
<p>
Every day, MIDM computes 2 sets of files for each DC:</p>
<p>
  - Hourly MIDM Enriched Records</p>
<p>
  - Daily MIDM Aggregated Records</p>
<p>
At the end of processing, MIDM transfers these 25 files per DC to VZW IT over the EDN network.</p>

<h4>1.2.1 System Overview</h4>
<h6>midm_processing.png</h6>
<br><br>
 <img border="0" src="$image_path/midm_processing.png" alt="Pulpit rock" width="700" height="400" align="middle">

<!-- PAGE BREAK -->
<h4>1.2.2 Monitoring Points & System KPIs</h4>
 <p>The diagram below shows where the KPIs charted in this report are monitored in the system.</p>
<br><br><br />
  <img border="0" src="$image_path/monitoring_kpi.png" alt="Pulpit rock" width="700" height="400" align="middle">
<br><br>
<h4>1.2.3 Glossary</h4>
<p><b>HTTP/IPFix:</b> records containing URLs browsed by a subscriber during a HTTP transaction along the source IP used.</p>
<p><b>Pilot Packet:</b> AAA-type records containing MDN + granted IP+Port</p>
<p><b>SubscriberIB:</b>  HTTP/IPFIX  and Pilot Packet records are processed into SubscriberIB  files at the DC. SubscriberIB basically tracks open subscriber sessions.</p>
<p><b>DC data:</b> Includes HTTP/IPFix, Pilot Packet and SubscriberIB data collected in the DC.  DC data is gathered and transmitted to SAP within 10 minutes of actual customer activity; </p>
<p><b>MIDM Application:</b> Application running in SAP in Colorado Springs. Processes DC data to generate MIDM data (Aggregate and Enriched records).</p>
<p><b>MIDM Processing:</b> HTTP  transactions (http tx)  and SubscriberIB  files are processed by MIDM MidmEnr processing jobs (one per DC) with CIL and White List files to create:</p>
&nbsp;&nbsp; - MidmAgg (aggregation, one file per day per DC) and
<br>&nbsp;&nbsp; - MidmEnr (enrichment, one file per hour per DC per day) (one per DC)
<br>and then zip compress each file
<p><b>CIL files:</b> Customer Inclusion List: Subscriber (MDN) opt-in list. MIDM opt-in / opt-out requirements and the related CIL file processing requirement introduce the 2 day delay.</p>
<p><b>White List files:</b> List of URLs to exclude.</p>
<p><b>MIDM Aggregate Data Record (MidmAgg):</b> The deep packet inspection appliance generates a fair portion of usage activity for image, script, and style-sheet web requests. Such events are consolidated into records for specific domains identified by VZW marketing team. Data is aggregate daily per subscriber.</p>
<p><b>MIDM Enriched CDR&#39;s (MidmEnr):</b> Business insights on subscriber attributes based on web browsing activity, application download and usage activity. Subscriber usage traffic and subscriber identity (Pilot Packet) from the VZW packet data network is analyzed for network operations use cases as part of the CMDS project. These usage records are re-purposed by the Guavus MI DM application to generate and deliver enriched CDR’s and daily transfer to VZW IT.</p>
<p><b>MIDM Data Transfer to VZW IT:</b>  After MIDM processing, MidmData jobs retrieve the MIDM Enriched and MIDM Aggregated record files and transfer them to VZW IT. </p>
<p><b>Network Security Application:</b> Application running in SAP in Colorado Springs. Uses DC data when receiving network events from Arcsight to retrieve & correlate IP & MDN information that is then returned to Arcsight for further processing.</p>
<p><b>SAP:</b> Subscriber Analytics Platform running in Colorado Springs and supporting the MIDM and Network Security applications.</p>

<!-- PAGE BREAK -->
DATA

  return $html_execReporting;
}


sub html_perfSummary {
  my ($data_from_date, $data_to_date) = @_;

#<h2 align="center"><a id="perfSummary">Performance Management Summary</h2>
#<h3 align="center">Data Date Range: $data_from_date to $data_to_date</h3>
  my $html_perfSummary = <<DATA;

<h2>2. Distribution Center Pairs Reports</h2>
<ol type="a">
  <li><h4>System Events</li></h4>
<!-- PAGE BREAK -->
DATA

  return $html_perfSummary;
}


sub html_siteMetrics {
  my ($site_names, $site1, $site2, $point, $ver) = @_;

  my $html_siteMetrics = <<DATA;

<!--Site Specific Graphs-->
<h3><a id="$site1:${site2}">$point $site_names</a></h3>
<ol type="a">
  <li><h4>Software Versions</li></h4>
  <p>$ver</p>
  <li><h4>HTTP (IPFIX) Data Volume at SAP (Bytes)</li></h4>
    <img border="0" src="$image_path/$site1:${site2}_SAP_IPFIX_DC_volume.png" alt="Pulpit rock" width="925" height="350">

  <br><br>
  <li><h4>Pilot Packet Data Volume at SAP (Bytes)</li></h4>
    <img border="0" src="$image_path/$site1:${site2}_SAP_PilotPacket_DC_volume.png" alt="Pulpit rock" width="925" height="350">

  <!-- PAGE BREAK -->
  <li><h4>Subscriber IB Data Volume at SAP (Bytes)</li></h4>
    <img border="0" src="$image_path/$site1:${site2}_SAP_SubscriberIB_DC_volume.png" alt="Pulpit rock" width="925" height="350">

  <br><br>
  <li><h4>MIDM Enriched Data Volume Generated For The DC Pair (Bytes)</li></h4>
    <img border="0" src="$image_path/$site1:${site2}_MIDM_enriched_data_DC_volume.png" alt="Pulpit rock" width="925" height="350">

  <br><br>
  <li><h4>MIDM Aggregated Data Volume Generated For The DC Pair (Bytes)</li></h4>
    <img border="0" src="$image_path/$site1:${site2}_MIDM_aggregated_data_DC_volume.png" alt="Pulpit rock" width="925" height="350">

  <br><br>
  <li><h4>MIDM data processing Duration For The DC Pair (Hours)</li></h4>
    <img border="0" src="$image_path/$site1:${site2}_MIDM_data_processing_DC_duration.png" alt="Pulpit rock" width="925" height="350">

  <br><br>
  <li><h4>MIDM data transfer Duration For The DC Pair (Hours)</li></h4>
    <img border="0" src="$image_path/$site1:${site2}_MIDM_data_transfer_DC_duration.png" alt="Pulpit rock" width="925" height="350">
</ol>

<!-- PAGE BREAK -->

DATA

  return $html_siteMetrics;
}



sub htmlEnd {
  my $html_end = <<DATA;
</body>
</html>
DATA
  return $html_end;
}
