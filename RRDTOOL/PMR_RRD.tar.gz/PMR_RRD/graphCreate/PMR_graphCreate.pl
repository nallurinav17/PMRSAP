#!/usr/bin/perl

use strict;
use Time::Local;
use Data::Dumper;

my $RRD = $ENV{RRDTOOL};

my $save_dir = $ENV{BASEPATH} ."/htmlGen/images";

my $start_date = $ARGV[0];
my $end_date   = $ARGV[1];

my @sd = split(/\-/, $start_date);
my @ed = split(/\-/, $end_date);

my $start = time - (timelocal(0,0,0,$sd[2], $sd[1] - 1, $sd[0] - 1900));
my $end   = time - (timelocal(0,0,0,$ed[2], $ed[1] - 1, $ed[0] - 1900));

# Overall Graphs
my $graph_cmd = <<DATA;

$RRD graph $save_dir/enriched_aggregeted_total_volume.png \\
-w 1085 -h 320 -a PNG \\
--zoom 2 \\
--start -$start --end -$end \\
--font DEFAULT:7: \\
--title "Enriched MIDM Data, Aggregated MIDM Data for all DCs" \\
--watermark "`date`" \\
--vertical-label "Data Volume(GB)" \\
--lower-limit 0 \\
--right-axis 1:0 \\
--x-grid DAY:30:DAY:7:DAY:1:0:%m/%d \\
DEF:enriched_total_volume=$ENV{SCHEMADATAPATH}/MIDM_enriched_data_total_volume.rrd:MIDM_EDTV:AVERAGE \\
DEF:aggregated_total_volume=$ENV{SCHEMADATAPATH}/MIDM_aggregated_data_total_volume.rrd:MIDM_ADTV:AVERAGE \\
AREA:enriched_total_volume#0000FF:"Enriched MIDM Data Volume(GB)" \\
STACK:aggregated_total_volume#FF00FF:"Aggregeted MIDM Data Volume(GB)" \\

DATA

print "$graph_cmd\n";
`$graph_cmd`;

$graph_cmd = <<DATA;

$RRD graph $save_dir/processed_transfer_total_duration.png \\
-w 1085 -h 320 -a PNG \\
--zoom 2 \\
--alt-autoscale-max \\
--start -$start --end -$end \\
--font DEFAULT:7: \\
--title "MIDM data processing, MIDM Transfer duration for all DCs" \\
--watermark "`date`" \\
--vertical-label "Duration(Hours)" \\
--lower-limit 0 \\
--right-axis 1:0 \\
--x-grid DAY:30:DAY:7:DAY:1:0:%m/%d \\
DEF:transfer_total_duration=$ENV{SCHEMADATAPATH}/MIDM_data_transfer_total_duration.rrd:MIDM_DTTD:AVERAGE \\
DEF:processing_total_duration=$ENV{SCHEMADATAPATH}/MIDM_data_processing_total_duration.rrd:MIDM_DPTD:AVERAGE \\
HRULE:20#0000FF:"MIDM Transfer Duration Threshold=20Hours":dashes \\
HRULE:12#FF00FF:"MIDM Processing Duration Threshold=12Hours":dashes \\
LINE3:transfer_total_duration#0000FF:"MIDM Transfer Duration(Hours)" \\
LINE3:processing_total_duration#FF00FF:"MIDM Processing Duration(Hours)" \\

DATA

print "$graph_cmd\n";

`$graph_cmd`;

my %pair_sites;
# Site specific graphs
my $site_pairs = eval {do "$ENV{BASEPATH}/etc/SitePair.cfg"};

foreach my $pairs (@$site_pairs) {
  my ($sites)     = keys %$pairs;
  my ($sitesValues) = values %$pairs;

  my ($sitesName) = keys %$sitesValues;
  my ($sitesArea) = values %$sitesValues;
  $sitesName =~ s/ & /:/;

  $pair_sites{$sites} = $sitesName;
}

#print Dumper(\%pair_sites);exit;
#$pair_sites{'NWCSDEBG:WMTPPAAA'} = 'Wilmington:Plymouth Meeting';

my @counters = qw(MIDM_aggregated_data_DC_volume MIDM_data_processing_DC_duration MIDM_data_transfer_DC_duration MIDM_enriched_data_DC_volume SAP_IPFIX_DC_volume SAP_PilotPacket_DC_volume SAP_SubscriberIB_DC_volume);

foreach my $sites (keys %pair_sites) {
  my @sites = split(/\:/, $sites);
  my @sites_name = split(/\:/, $pair_sites{$sites});

  foreach my $counter(@counters) {

    my $pngFileName = $sites.'_'.$counter . '.png';
    my $rrdTheme = $sites.'_'.$counter; $rrdTheme =~ s/_/ /g;
    my $counterTheme = $counter; $counterTheme =~ s/_/ /g; $counterTheme =~ s/ DC / /g;
    $counterTheme .= '(GB)' if($counter =~ /_volume/);
    $counterTheme .= '(Hours)' if($counter =~ /_duration/);
    
    my $rrdFileName1 = $sites[0] .'-'.$counter;
    my $rrdFileName2 = $sites[1] .'-'.$counter;

    my $vertical_label = 'Data Volume(GB)'; 
    $vertical_label = 'Duration(Hours)' if($counter =~ /_duration/);

    my $counter_pin = getCounterPin($counter);

    my $graph_cmd = <<DATA;

$RRD graph $save_dir/$pngFileName \\
-w 1085 -h 320 -a PNG \\
--zoom 2 \\
--alt-autoscale-max \\
--start -$start --end -$end \\
--font DEFAULT:7: \\
--title "$rrdTheme" \\
--watermark "`date`" \\
--vertical-label "$vertical_label" \\
--lower-limit 0 \\
--right-axis 1:0 \\
--x-grid DAY:30:DAY:7:DAY:1:0:%m/%d \\
DEF:s1_val=$ENV{SCHEMADATAPATH}/$rrdFileName1.rrd:$counter_pin:AVERAGE \\
DEF:s2_val=$ENV{SCHEMADATAPATH}/$rrdFileName2.rrd:$counter_pin:AVERAGE \\
LINE8:s1_val#24F708:"$sites[0] $counterTheme" \\
LINE2:s2_val#F70840:"$sites[1] $counterTheme" \\

DATA
#LINE3:s1_val#0000FF:"$counterTheme" \\
  print "$graph_cmd\n";

  `$graph_cmd`;

  }
}


sub getCounterPin {
  my $counter = shift;

  my $_val;
  foreach my $_a (split(/\_/, $counter)) {
    unless($_val) {
      $_val = $_a .'_';
    }
    else {
      $_val .= uc(substr($_a, 0, 1));
    }
  }
  return $_val;
}









