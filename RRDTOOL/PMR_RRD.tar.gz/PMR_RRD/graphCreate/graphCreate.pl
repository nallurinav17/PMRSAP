use strict;
use Time::Local;

my $RRD = 'rrdtool';

my $start = time - (timelocal(0,25,7,1,1-1,2014-1900));
my $end = time - (timelocal(0,25,7,30,1-1,2014-1900));


#--slope-mode \\
my $graph_cmd = <<DATA;

$RRD graph enriched_graph.png \\
-w 1085 -h 320 -a PNG \\
--start -$start --end -$end \\
--font DEFAULT:7: \\
--title "Total MIDM Data Volume" \\
--watermark "`date`" \\
--vertical-label "Data Volume(GB)" \\
--lower-limit 0 \\
--right-axis 1:0 \\
--x-grid DAY:30:DAY:7:DAY:1:0:%m/%d \\
--alt-y-grid --rigid \\
DEF:enriched_total_volume=../schema/MIDM_enriched_data_total_volume.rrd:MIDM_EDTV:AVERAGE \\
DEF:aggregated_total_volume=../schema/MIDM_aggregated_data_total_volume.rrd:MIDM_ADTV:AVERAGE \\
AREA:enriched_total_volume#0000FF:"Enriched MIDM Data Volume(GB)" \\
STACK:aggregated_total_volume#FF00FF:"Aggregeted MIDM Data Volume(GB)" \\

DATA

print "$graph_cmd\n";

`$graph_cmd`;


