prefix="10.136.239."
cnp="118 88"
cmp="62 63 64 65 89 90 91 92 93 94 95 96 97 98 99 101 102 103 104 105 106 107 108 109 110 111 112 113 119 120 121 122 123 124 125 126 127 128 129 130 131 132 133 134 135 136 137 138 139 140 141 142"

mgmt="63 65"

ccp="114 143"
sgp1="116 145"
sgp2="117 146"
uip="115 144"
cnp0="147"
ccp0="155"
sgp0="148"
uip0="154"
#dclist="Azusa Branchburg Charlotte HickoryHills Marina Nashville NewBerlin Ontario PlymouthMeeting Vista Wall Wilmington"


